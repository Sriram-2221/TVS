package com.example.demo.entity; 
import jakarta.persistence.CascadeType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity


@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDetails {
	
    @Id
    @Column(name = "ID")
    @GeneratedValue
	private int empId;
    
    @Column(name = "Name")
	private String name;
    
    @Column(name = "Gender")
	private String gender;
    
    @OneToOne(cascade = CascadeType.ALL)
    private AddressDetails address;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public AddressDetails getAddress() {
		return address;
	}

	public void setAddress(AddressDetails address) {
		this.address = address;
	}
    

    

}
