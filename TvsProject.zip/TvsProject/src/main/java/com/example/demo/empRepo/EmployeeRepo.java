package com.example.demo.empRepo;

import org.springframework.data.jpa.repository.JpaRepository; 

import com.example.demo.entity.EmployeeDetails;

public interface EmployeeRepo extends JpaRepository<EmployeeDetails,Integer>{

}
