package com.example.demo.service;

import java.util.List;  

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.empRepo.AddressRepo;
import com.example.demo.empRepo.EmployeeRepo;
import com.example.demo.entity.EmployeeDetails;

@Service
public class EmployeeService {
@Autowired	
private EmployeeRepo employeerepo;


public EmployeeDetails saveDetails(EmployeeDetails emp) {
	return employeerepo.save(emp);
	
}

public EmployeeDetails getbyId(int id) {
	return employeerepo.findById(id).orElse(null);
	
}

public  List<EmployeeDetails> getAlldetails(){
	return employeerepo.findAll();
	
}

public String deleteEmployee(int id) {
	if(employeerepo.existsById(id)) {
	employeerepo.deleteById(id);
	return "deleted "+id;}
	else {
		return "Id not exists";
	}
}

public EmployeeDetails updateDetail(EmployeeDetails emp) {
	EmployeeDetails Update = employeerepo.findById(emp.getEmpId()).orElse(null);
	if(Update!=null) {
		Update.setName(emp.getName());
		Update.setGender(emp.getGender());
		employeerepo.save(Update);
		return Update;
	}
	return null;
}
}
