package com.example.demo.empRepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.AddressDetails;

public interface AddressRepo extends JpaRepository<AddressDetails,Integer> {

}
